DUSTLINE - ek hi zip mein sab kuchh

1_PROJECT_github_par_daalo
   -> Iske ANDAR ka saara content GitHub (private repo) par upload karo, .github folder samet.
   -> (Privacy-policy link pehle se set hai: https://battle-royal-privacy-kanishkdevloperr.netlify.app/ - badalna ho to) python3 tools/set_contact.py https://<user>.github.io/<repo>/privacy-policy.html
   -> Phir Actions > Build Dustline > Run workflow. app-release.aab Play Console par jaata hai.
   -> Poori steps: PLAY_STORE/BUILD_AND_UPLOAD.md aur PLAY_STORE/SUBMISSION_CHECKLIST.md

2_PROOF_PRIVATE_sirf_apne_paas_rakho
   -> CGTrader screenshots + character licence proof. GitHub par KABHI mat daalna. Play Store ko bhi nahi dena.
   -> Phone / Google Drive mein safe rakho. Saath mein FBX, ChatGPT chats, Sketchfab .glb files bhi rakho.

VERSION 1.0.7 (latest: AdMob consent test + guide PLAY_STORE/ADMOB_CONSENT_SETUP.md). Pehle 1.0.6: vehicles ke aakhri nishaan hata diye, CC BY credits poore kiye. Kya badla: CHANGES_KYA_BADLA.txt.
ADS (naya): test ID hata di, diamond ke liye 4 real ID round-robin (barabar request), 2x coin ke liye alag slot - CHANGES_KYA_BADLA.txt #35-40.
Upload se pehle 3 kaam aapke: (1) privacy policy ka link set_contact.py se, (2) GitHub Actions build chalakar error check, (3) Play Console mein content rating (IARC) poori bharo - bina rating ke app allowed nahi.
