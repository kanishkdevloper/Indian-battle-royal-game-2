# Survivor character - licence proof (PRIVATE, never publish)

Model: FREE Survival Character Free low-poly 3D model
Author: Arberry (CGTrader)   Model ID: #4323274   Published: 2023-02-26
Licence shown on the CGTrader page: **Royalty Free License (no AI)** - "Free for personal and commercial use".
Page data: 49,068 polygons / 60,433 vertices, rigged, PBR.
Screenshots of the page (your phone, 2026-11-10 19:30-19:31): cgtrader_page_1..4.jpg in proof/cgtrader/.

## Mesh match (app vs. the FBX you downloaded)
FBX (Survival_Character.fbx, binary v7400): 11 meshes -> vertex counts 844, 1354, 2145, 2602, 4149, 4592, 5335, 5628, 9132, 11201, 31515.
App (models/character, descrambled): 11 parts -> 942, 1646, 2410, 2602, 4739, 5010, 5628, 6341, 9803, 13951, 31515.
Exact matches: 2602, 5628, 31515. The other 8 are slightly larger in the app, as expected (vertices are split at UV / hard-normal seams when the mesh is exported for OpenGL).
Conclusion: the app character IS this CGTrader model.

## Duties of the licence (as understood - re-read the licence text on CGTrader once)
1. Use in a game/app is allowed, commercial use is allowed.
2. The model must not be extractable as a standalone file -> the 13 files are scrambled (Prot.kt / tools/protect_character.py). Never publish the FBX or source_assets/.
3. "No AI": the model must not be used to train or feed AI. It is not.
4. Keep: your CGTrader account download record (Downloads page), the FBX, these screenshots.

## Licence text read on 2026-11-11 (CGTrader help centre)
- https://help.cgtrader.com/hc/en-us/articles/360015193418 : "Products sold with Royalty Free license can be used for commercial purposes." Examples: video game, film, animation, VR/AR application. No extra royalties for multiple use.
  Forbidden: the model "may not be sold, given, or assigned to any other person or entity in the form it is downloaded from the site."
- https://help.cgtrader.com/hc/en-us/articles/360015122437 (commercial use of a model): allowed "as long as it is incorporated into the product" and "as long as the 3rd party cannot retrieve it on its own in both digital and physical form."
- Attribution: not required (a courtesy credit is shown anyway).
=> Game use OK. The only duty is: no loose/standalone model file for users. Dustline ships it inside the APK, scrambled (Prot.kt). Residual risk: scrambling is obfuscation, not encryption; a determined person could still dump it. Never publish the FBX / source_assets / descrambling tool.
